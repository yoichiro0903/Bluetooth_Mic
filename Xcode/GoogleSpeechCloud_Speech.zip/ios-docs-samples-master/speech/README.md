# Cloud Speech iOS Samples

These apps demonstrate how to make API calls to the [Cloud Speech API](https://cloud.google.com/speech/), using audio recorded from an iOS device's microphone. Check out each app's README for full getting started instructions.

Please note: As this new service is rolled out, early users will be whitelisted. To learn more and to apply for access, please visit http://cloud.google.com/speech.

## Contents

### [Objective-C](Objective-C)

### [Swift](Swift)

