
This directory contains a Stickynote API REST server 
suitable for running on Google App Engine Standard.

