# REST

Clients and servers for a REST version of the Sticky Note API.
For a complete description, please see
[Build a mobile app using Google Compute Engine and REST](https://cloud.google.com/solutions/mobile/mobile-compute-engine-rest).

## Contents

### [Objective-C](Objective-C)

An Objective-C client.

### [Swift](Swift)

A Swift client.

### [Go](Go)

A Go server and test client.

