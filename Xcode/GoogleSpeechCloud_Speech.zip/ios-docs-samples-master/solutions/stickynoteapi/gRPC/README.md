# gRPC

Clients and servers for a gRPC version of the Sticky Note API.
For a complete description, please see
[Build a mobile app using Google Compute Engine and gRPC](https://cloud.google.com/solutions/mobile/mobile-compute-engine-grpc).

## Contents

### [Objective-C](Objective-C)

An Objective-C client.

### [Swift](Swift)

A Swift client.

### [Go](Go)

A Go server and test client.

