iSensor
=======

Sense a lot of things. Swift version [here](https://github.com/koogawa/iSensorSwift/)

1. Proximity Monitoring
2. Screen Brightness
3. Shake Gesture
4. Location
5. Heading
6. Altitude
7. Audio
8. Accelerometer
9. Motion Activity
10. Face Detection
11. Battery
12. Speed

