//
//  SpeedViewController.h
//  iSensor
//
//  Created by koogawa on 2015/01/04.
//  Copyright (c) 2015年 Kosuke Ogawa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface SpeedViewController : UIViewController <CLLocationManagerDelegate>

@end
