//
//  FaceDetectionViewController.h
//  iSensor
//
//  Created by koogawa on 2013/11/30.
//  Copyright (c) 2013年 Kosuke Ogawa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FaceDetectionViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIImageView *imageView;

@end
