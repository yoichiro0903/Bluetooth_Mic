//
//  main.m
//  GoogleSearchApiSample
//
//  Created by satoshi hattori on 2016/01/11.
//  Copyright © 2016年 satoshi hattori. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
