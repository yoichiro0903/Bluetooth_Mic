//
//  AppDelegate.h
//  GoogleSearchApiSample
//
//  Created by satoshi hattori on 2016/01/11.
//  Copyright © 2016年 satoshi hattori. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

