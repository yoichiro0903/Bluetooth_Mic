testDictation
=============

iOSでの音声認識テスト。非公開のUIDictationControllerを使用。
テスト環境【Xcode5.1.1 + iOS 7.1 + MacOX10.9.5】
